<template>
    <div style="height: 100%;width: 100%">
      <tcc-layout></tcc-layout>
    </div>
</template>

<script>
  export default {
    name: 'index',
    props: [],
    mounted () {
    }
  }
</script>

<style scoped>

</style>
